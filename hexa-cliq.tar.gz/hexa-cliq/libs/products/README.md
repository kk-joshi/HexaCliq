# products

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test products` to execute the unit tests.
