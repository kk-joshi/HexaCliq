export class Category {
  id?: string;
  name?: string;
  icon?: string;
  color?: string;
  checked?: boolean;
}
