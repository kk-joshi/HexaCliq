import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'products-search',
  templateUrl: './products-search.component.html',
  styles: [
  ]
})
export class ProductsSearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
