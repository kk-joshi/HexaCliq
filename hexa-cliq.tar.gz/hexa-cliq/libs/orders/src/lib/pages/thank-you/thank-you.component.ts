import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'orders-thank-you-page',
  templateUrl: './thank-you.component.html',
  styles: [
  ]
})
export class ThankYouComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
