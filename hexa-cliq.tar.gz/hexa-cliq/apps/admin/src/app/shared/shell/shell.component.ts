import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'admin-shell',
  templateUrl: './shell.component.html',
})
export class ShellComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
