import { Component, OnInit } from '@angular/core';
import { CartService } from '@bluebits/orders';

@Component({
  selector: 'ngshop-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
