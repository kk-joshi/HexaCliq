import { Component } from '@angular/core';

@Component({
  selector: 'bluebits-root',
  templateUrl: './app.component.html',
})
export class AppComponent {
  title = 'Hexa CliQ';
}
